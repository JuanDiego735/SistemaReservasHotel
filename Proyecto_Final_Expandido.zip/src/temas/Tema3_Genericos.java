package temas;

class Contenedor<T> {
    private T valor;

    public void set(T valor) {
        this.valor = valor;
    }

    public T get() {
        return valor;
    }
}

public class Tema3_Genericos {
    public static void main(String[] args) {
        Contenedor<String> c1 = new Contenedor<>();
        c1.set("Hola Genérico");
        System.out.println(c1.get());
    }
}