package temas;

sealed interface Animal permits Perro, Gato {}

final class Perro implements Animal {}
final class Gato implements Animal {}

public class Tema7_SealedClasses {
    public static void main(String[] args) {
        Animal a = new Perro();
        System.out.println("Animal creado: " + a.getClass().getSimpleName());
    }
}