package temas;

interface Procesador<T> {
    void procesar(T dato);
}

class ProcesadorString implements Procesador<String> {
    public void procesar(String dato) {
        System.out.println("Procesando: " + dato.toUpperCase());
    }
}

public class Tema4_InterfacesGenericas {
    public static void main(String[] args) {
        Procesador<String> ps = new ProcesadorString();
        ps.procesar("texto");
    }
}