package temas;

import java.util.*;

public class Tema2_Iterator {
    public static void main(String[] args) {
        List<String> frutas = new ArrayList<>(Arrays.asList("Manzana", "Banana", "Pera"));
        
        // Iterator
        Iterator<String> it = frutas.iterator();
        while (it.hasNext()) {
            String f = it.next();
            if (f.equals("Banana")) it.remove();
        }
        
        // ListIterator
        ListIterator<String> listIt = frutas.listIterator();
        while (listIt.hasNext()) {
            String f = listIt.next();
            listIt.set(f.toUpperCase());
        }
        
        System.out.println("Modificado: " + frutas);
    }
}