package temas;

import java.util.*;

public class Tema1_Colecciones {
    public static void main(String[] args) {
        Set<String> conjunto = new HashSet<>();
        conjunto.add("Perú");
        conjunto.add("Colombia");
        conjunto.add("Chile");
        conjunto.add("Perú"); // Duplicado

        List<String> lista = new ArrayList<>(conjunto);
        lista.add("Argentina");

        Map<Integer, String> mapa = new HashMap<>();
        mapa.put(1, "Uno");
        mapa.put(2, "Dos");

        System.out.println("Set: " + conjunto);
        System.out.println("List: " + lista);
        System.out.println("Map: " + mapa);
    }
}