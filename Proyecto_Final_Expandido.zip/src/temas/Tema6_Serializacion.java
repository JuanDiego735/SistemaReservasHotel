package temas;

import java.io.*;
import java.util.*;

class Usuario implements Serializable {
    String nombre;
    int edad;
    public Usuario(String n, int e) {
        nombre = n; edad = e;
    }
}

public class Tema6_Serializacion {
    public static void main(String[] args) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("usuario.ser"))) {
            Usuario u = new Usuario("Juan", 20);
            oos.writeObject(u);
            System.out.println("Usuario serializado.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}