package temas;

import java.util.*;
import java.util.stream.*;

public class Tema5_Funcional {
    public static void main(String[] args) {
        List<String> nombres = Arrays.asList("Ana", "Luis", "Pedro", "Lucía");

        nombres.stream()
               .filter(n -> n.startsWith("L"))
               .map(String::toUpperCase)
               .sorted()
               .forEach(System.out::println);
    }
}