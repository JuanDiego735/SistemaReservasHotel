# Proyecto Final - Ejemplos de Java Avanzado

Este proyecto contiene ejemplos por separado de los siguientes temas:

- `Tema1_Colecciones`: Uso de Set, List y Map.
- `Tema2_Iterator`: Uso de Iterator y ListIterator para modificar listas.
- `Tema3_Genericos`: Clase genérica simple.
- `Tema4_InterfacesGenericas`: Interfaces genéricas implementadas con distintos tipos.
- `Tema5_Funcional`: Programación funcional con streams.
- `Tema6_Serializacion`: Serialización de objetos.
- `Tema7_SealedClasses`: Ejemplo de sealed classes (Java 17+).

Cada clase puede ejecutarse individualmente en NetBeans.

## Requisitos
- JDK 17+
- NetBeans o cualquier IDE que soporte Java

## Cómo ejecutar
Abre el proyecto en NetBeans, haz clic derecho sobre cualquier clase en `src/temas/` y selecciona **Run File**.

¡Listo para exponer o subir a GitHub!